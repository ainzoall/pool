/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 19:15:45 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/23 19:44:11 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>

int	ft_pow(int i, int p)
{
	int	x;

	x = 0;
	i = i - 48;
	while (x < p)
	{
		i = i * 10;
		x++;
	}
	return (i);
}

int	ft_is_pass(char	*str)
{
	if (*str >= '0' && *str <= '9')
		return (0);
	if (*str == ' ')
		return (0);
	if (*str == '+')
		return (0);
	if (*str == '-')
		return (0);
	return (1);
}

int	num_len(char	*str)
{
	int	i;
	int	x;

	x = 0;
	i = 0;
	while (*str)
	{
		if (*str >= '0' && *str <= '9')
		{
			x = 1;
			i++;
		}
		else if (x == 1)
			break ;
		str++;
	}
	return (i);
}

int	ft_iota(char	*str)
{
	int	j;
	int	i;

	j = 0;
	i = num_len(str);
	while (*str >= '0' && *str <= '9')
	{
		j = j + ft_pow(*str, --i);
		str++;
	}
	return (j);
}

int	ft_atoi(char	*str)
{
	int		neg;
	int		j;

	neg = 1;
	j = 0;
	while (*str)
	{
		while (isspace(*str))
			str++;
		if (ft_is_pass(str) || (*str == ' ' && j > 0))
			break ;
		if (*str == '-' && j == 0)
			neg = neg * -1;
		if (*str >= '0' && *str <= '9')
		{
			return (ft_iota(str) * neg);
		}
		str++;
	}
	return (0);
}
