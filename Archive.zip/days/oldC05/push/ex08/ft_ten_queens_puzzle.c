/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/26 15:40:05 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/26 15:40:05 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	long	nbr;
	char	x;

	nbr = nb;
	if (nbr < 0)
	{
		write(1, "-", 1);
		nbr = nbr * -1;
	}
	if (nbr <= 9)
	{
		x = nbr + '0';
		write(1, &x, 1);
	}
	else
	{
		ft_putnbr(nbr / 10);
		ft_putnbr(nbr % 10);
	}
}
int	ft_ten_queens_puzzle(void);
int	main()
{
	ft_ten_queens_puzzle();	
}

int xmover(int x,int move)
{
	if((move == 0 || move == 1) && x+2 < 10)
		return (x+2);
	if((move == 2 || move == 7) && x+1 < 10)
		return (x+1);
	if((move == 3 || move == 6) && x-1 > 0)
		return (x-1);
	if((move == 4 || move == 5) && x-2 < 10)
		return (x-2);
	return (-1);
}

int ymover(int y,int move)
{
	if((move == 0 || move == 5) && y - 1 > 0)
		return (y - 1);
	if((move == 1 || move == 4) && y + 1 < 10)
		return (y + 1);
	if((move == 2 || move == 3) && y + 2 < 10)
		return (y + 2);
	if((move == 6 || move == 6) && y - 2 < 10)
		return (y - 2);
	return (-1);
}
int eater(int px,int py,int **grid)
{
	int x;
	int y;
	while(grid[x] )

}
int mover(int x, int y, int n)
{
	int xm;
	int ym;
	int move;

	while (n > 0)
	{
		move = n % 8;
		if
		n--;
	}
}
int ft_ten_queens_puzzle(void)
{
	int grid[10][10] = {0};
}


















