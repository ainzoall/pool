/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 10:34:03 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/24 10:44:56 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	size;

	size = 0;
	while (str[size] != '\0')
		size++;
	return (size);
}

int	ft_vl_base(char *base)
{
	int	s;
	int	z;

	s = 0;
	while (base[s])
	{
		if (base[s] == '+' || base[s] == '-' || base[s] == ' ')
			return (0);
		z = s + 1;
		while (base[z])
		{
			if (base[s] == base[z])
				return (0);
			z++;
		}
		s++;
	}
	return (s);
}

int	bak(int key, int base)
{
	int	r;

	r = 1;
	while (key > 0)
	{
		r *= base;
		key--;
	}
	return (r);
}

int	ft_base(int key, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == key)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *str, char *base)
{
	int	neg;
	int	baselen;
	int	i;
	int	j;
	int	x;

	neg = 1;
	baselen = ft_vl_base(base);
	while (*str == '-' || *str == '+' || *str == ' ' || *str == '\n'
		|| *str == '\r' || *str == '\t' || *str == '\v')
	{
		if (*str == '-')
			neg *= -1;
		str++;
	}
	if (baselen <= 1)
		return (0);
	i = ft_strlen(str) - 1;
	j = 0;
	x = 0;
	while (i >= 0)
	{
		j = j + ft_base(str[i--], base) * bak(x++, baselen);
	}
	return (j * neg);
}
