/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 15:44:25 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/25 10:11:09 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
int main(int argc, char *argv[])
{
	int j;
	
	argc--;
	while(argc > 0)
	{
		j = 0;
		while(argv[argc][j])
		{
			write(1, &argv[argc][j], 1);
			j++;	
		}
		write(1, "\n", 1);
		argc--;
	}
}
