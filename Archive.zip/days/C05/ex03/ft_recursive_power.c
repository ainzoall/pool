/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/25 21:45:38 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/26 00:12:56 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	if (power == 0)
		return (1);
	if (nb == 0 && power == 0)
		return (0);
	if (power < 0)
		return (0);
	if (power - 1 != 0)
		return (nb * ft_recursive_power(nb, power - 1));
	return (nb);
}
