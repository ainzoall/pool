/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/25 23:32:33 by efelaous          #+#    #+#             */
/*   Updated: 2023/08/01 03:35:27 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;
	int	count;

	if (nb < 0)
		return (0);
	if (nb == 2 || nb == 3)
		return (1);
	if (nb % 2 == 0 || nb == 0 || nb == 1)
		return (0);
	i = 3;
	count = 0;
	while (i < 46360)
	{
		if (nb % i == 0)
			count++;
		i += 2;
	}
	if (count <= 1)
		return (1);
	return (0);
}

int	ft_find_next_prime(int nb)
{
	int	i;

	if (nb <= 2)
		return (2);
	i = nb;
	while (!ft_is_prime(i))
		i++;
	return (i);
}
