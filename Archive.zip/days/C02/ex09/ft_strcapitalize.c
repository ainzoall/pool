/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/16 18:44:36 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/17 09:34:07 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>

char	*ft_strcapitalize(char *str)
{
	char	*final;

	final = str;
	if ((*str >= 'a' && *str <= 'z'))
		*str = *str - 32;
	str++;
	while (*str)
	{
		str--;
		if (!(((*str >= 'a' && *str <= 'z') || (*str >= 'A' && *str <= 'Z')
					|| (*str >= '0' && *str <= '9'))))
		{
			str++;
			if (*str >= 'a' && *str <= 'z')
				*str = *str - 32;
		}
		else
		{
			str++;
			if (*str >= 'A' && *str <= 'Z')
				*str = *str + 32;
		}
		str++;
	}
	return (final);
}
