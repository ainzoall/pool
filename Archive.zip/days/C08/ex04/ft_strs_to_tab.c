/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/02 17:22:21 by efelaous          #+#    #+#             */
/*   Updated: 2023/08/03 17:24:27 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_stock_str.h"

char	*ft_strdup(char *src)
{
	char	*dest;
	int		len;

	len = 0;
	while (src[len])
		len++;
	dest = malloc((len + 1) * sizeof(char));
	len = 0;
	while (*src)
	{
		dest[len] = *src;
		src++;
		len++;
	}
	return (dest);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int			i;
	int			sz;
	t_stock_str	*final;

	final = malloc((ac + 1) * sizeof(struct s_stock_str));
	i = 0;
	while (i < ac)
	{
		sz = 0;
		while (av[i][sz])
			sz++;
		final[i].size = sz;
		final[i].str = &av[i][0];
		final[i].copy = ft_strdup(av[i]);
		i++;
	}
	final[i].str = 0;
	return (final);
}
