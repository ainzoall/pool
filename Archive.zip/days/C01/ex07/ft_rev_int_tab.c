/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/15 01:53:51 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/15 02:26:50 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h> 
 void	ft_rev_int_tab(int *tab, int size)
 {
    int z;
    int swap;


    z = 0;
    size--;
    while (z < size)
    {
        swap = tab[size];
        tab[size] = tab[z];
        tab[z] = swap;
        z++;
        size--;

    }

 }