/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/16 02:33:13 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/16 02:55:01 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>


void ft_sort_int_tab(int *tab, int size)
{
	int z;
	int tmp;
	z = 0;
	size--;
	while (z < size)
	{
		int r;
		r = z;
		while(r < size) {
			if (tab[size] > tab[r])
			{
				tmp = tab[size];
				tab[size] = tab[z];
				tab[z] = tmp;
			}
			r++;
		}
		z++;
		size--;
	}
	int m;
	while (m <= z)
	{
		int g = tab[m] + '0';
		write(1, &g, 1);
		m++;
	}
}

int main (void)
{
	int x = 2654;
	int tab[] = {2, 6, 5, 4};
	ft_sort_int_tab( tab, 4);
}