/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/04 02:02:41 by efelaous          #+#    #+#             */
/*   Updated: 2023/08/04 02:44:05 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int	ft_strlen(char *str)
{
	int	sz;

	sz = 0;
	while (str[sz] != 0)
	{
		sz++;
	}
	return (sz);
}
int chars_len(char *str, char *charset)
{
	int	charlen;
	int	j;
	int	i;
	int	dec;

	charlen = ft_strlen(charset);
	dec = 0;
	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i + j] != 0 && str[i + j] == charset[j])
			j++;
		if (charset[j] != 0)
			i++;
		else
			return (++i);
	}
	return (0);
}

char **ft_split(char *str, char *charset)
{
	char	**retn;
	int	j;
	int	i;
	int	s;

	retn = malloc(sizeof(char **) * (chars_len(str, charset) + 1));
	i = 0;
	s = 0;
	while (str[i])
	{
		j = 0;
		while (str[i + j] != 0 && str[i + j] == charset[j])
			j++;
		if (charset[j] == 0 || i == 0)
		{
			int sub_len = 0;
			while (str[i + sub_len] != 0 && str[i + sub_len] != charset[0])
				sub_len++;

			retn[s] = malloc(sizeof(char) * (sub_len + 1)); // +1 for the null terminator
				  int k = 0;
                while (k < sub_len)
                {
                    retn[s][k] = str[i + k];
                    k++;
                }
                retn[s][k] = '\0'; // Add null terminator at the end of the substring.
                s++;
		}
		i++;
	}
	retn[s] = NULL;
	return (retn);
}

#include <stdio.h>
int main()
{
	
	char str[]= "hello;world;this;is;a;tset";
	char charset[] = ";";
	char **test = ft_split(str, charset);
	int i =  0;
	while (i < chars_len(str, charset))
	{
		printf("%s\n", test[i]);
		i++;
	}
}