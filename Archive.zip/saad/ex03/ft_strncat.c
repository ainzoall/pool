/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 18:25:16 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/20 20:06:52 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char				*stc;
	unsigned int		unb;

	unb = 0;
	stc = dest;
	while (*dest)
		dest++;
	if (*src == '\0')
		return (stc);
	while (unb < nb)
	{
		*dest = *src;
		dest++;
		src++;
		unb++;
	}
	*dest = '\0';
	return (stc);
}
int		main(void)
{
    char dest[50] = "Hello, ";
    char *src = "world!";
    unsigned int nb = 3;

    printf("Before ft_strncat: %s\n", dest);
    ft_strncat(dest, src, nb);
    printf("After ft_strncat: %s\n", dest);

    return (0);
}