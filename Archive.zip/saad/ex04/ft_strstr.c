/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 13:03:06 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/20 18:44:51 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{
		if (*str == *to_find)
		{
			while (*to_find != '\0')
			{
				if (*str == *to_find++)
					j++;
				i++;
				str++;
			}
			if (i == j)
				return (str - i);
		}
		else
			str++;
	}
	return (NULL);
}
