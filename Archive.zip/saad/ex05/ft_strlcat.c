/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:43:26 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/20 20:02:19 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

	#include <stdio.h>
#include <string.h>
unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	while (*dest != '\0' && i < size)
	{
		dest++;
		i++;
	}
	while (*src != '\0' && i < size - 1)
	{
		*dest = *src;
		dest++;
		src++;
		i++;
	}
	*dest = '\0';
	return (i);
}

int main()
{
    char dest[20] = "Hello, ";
    char src[] = "world!";
    unsigned int size = 0;
    unsigned int result = ft_strlcat(dest, src, size);
    printf("Result: %u\n", result);
    printf("Concatenated string: %s\n", dest);
    return 0;
}
