/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 17:48:55 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/20 21:37:31 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
char	*ft_strcat(char *dest, char *src)
{
	char	*stc;

	stc = dest;
	while (*dest)
		dest++;
	if (*src == '\0')
		return (dest);
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (stc);
}
int		main(void)
{
    char dest[50] = "asdasdas";
    char *src = "";

    printf("Before ft_strncat: '%s'\n", dest);
    ft_strcat(dest, src);
    printf("After ft_strncat: '%s'\n", dest);

    return (0);
}