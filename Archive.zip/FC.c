#include<unistd.h>

// The ft_putchar function in exercise 00 is a function that displays a character passed as a parameter using the write function. It has the following prototype: void ft_putchar(char c). To display the character, the function utilizes the write function as follows: write(1, &c, 1).
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

// The ft_print_alphabet function is a function that displays the lowercase alphabet in ascending order on a single line, starting from the letter 'a'. It has the following prototype: void ft_print_alphabet(void).
void	ft_print_alphabet(void)
{
	char	a;

	a = 97;
	while (a <= 122)
	{
		write(1, &a, 1);
		a++;
	}
}

// The ft_print_reverse_alphabet function is a function that displays the lowercase alphabet in descending order on a single line, starting from the letter 'z'. It has the following prototype: void ft_print_reverse_alphabet(void).
void	ft_print_reverse_alphabet(void)
{
	char	m;

	m = 'z';
	while (m >= 'a')
	{
		write(1, &m, 1);
		m--;
	}
}

// The ft_print_numbers function is a function that displays all the digits in ascending order on a single line. It has the following prototype: void ft_print_numbers(void).
void	ft_print_numbers(void)
{
	char	m;

	m = 48;
	while (m <= 57)
	{
		write(1, &m, 1);
		m++;
	}
}

// The ft_is_negative function is a function that displays 'N' or 'P' depending on the sign of the integer entered as a parameter. If the integer (n) is negative, it displays 'N'. If the integer (n) is positive or zero, it displays 'P'. It has the following prototype: void ft_is_negative(int n).
void	ft_is_negative(int n)
{
	if (n < 0)
	{
		write(1, "N", 1);
	}
	else
	{
		write(1, "P", 1);
	}
}

// The ft_print_comb function is a function that displays all different combinations of three different digits in ascending order, listed by ascending order, with the restriction that repetition is voluntary. It generates and displays the combinations in the following format: "012, 013, 014, ..., 789". However, it excludes combinations that have repeated digits, such as "999". The function has the prototype: void ft_print_comb(void).
void	ft_write_number(int x, int y, int z)
{
	write(1, &x, 1);
	write(1, &y, 1);
	write(1, &z, 1);
	if (x != '7')
	{
		write(1, ",", 1);
		write(1, " ", 1);
	}
}
void	ft_print_comb(void)
{
	int	x;
	int	y;
	int	z;

	x = '0';
	while (x <= '7')
	{
		y = x + 1;
		while (y <= '8')
		{
			z = y + 1;
			while (z <= '9')
			{
				ft_write_number(x, y, z);
				z++;
			}
			y++;
		}
		x++;
	}
}
