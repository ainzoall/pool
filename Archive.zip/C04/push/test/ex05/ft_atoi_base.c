/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 10:34:03 by efelaous          #+#    #+#             */
/*   Updated: 2023/08/03 19:50:40 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_isspace(char str)
{
	if (str == ' ' || (str >= 9 && str <= 13))
		return (1);
	return (0);
}

int	ft_vl_base(char *base)
{
	int	s;
	int	z;

	s = 0;
	while (base[s])
	{
		if (base[s] == '+' || base[s] == '-'
			|| base[s] == ' ' || (base[s] >= 9 && base[s] <= 13))
			return (0);
		z = s + 1;
		while (base[z])
		{
			if (base[s] == base[z])
				return (0);
			z++;
		}
		s++;
	}
	return (s);
}

int	ft_base(int key, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == key)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *str, char *base)
{
	int	neg;
	int	i;
	int	res;
	int	basel;

	basel = ft_vl_base(base);
	if (basel <= 1)
		return (0);
	neg = 1;
	i = 0;
	res = 0;
	while (ft_isspace(str[i]))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i++] == '-')
			neg *= -1;
	}
	while (str[i] != '\0' && ft_base(str[i], base) != -1)
	{
		res = (res * basel) + ft_base(str[i], base);
		i++;
	}
	return (res * neg);
}
