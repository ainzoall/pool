/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 02:47:10 by efelaous          #+#    #+#             */
/*   Updated: 2023/08/01 03:12:26 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char str)
{
	write(1, &str, 1);
}

int	ft_vl_base(char *base)
{
	int	s;
	int	z;

	s = 0;
	while (base[s])
	{
		if (base[s] == '-' || base[s] == '+')
			return (0);
		if (base[s] < 32 || base[s] == 127)
			return (0);
		z = s + 1;
		while (base[z])
		{
			if (base[s] == base[z])
				return (0);
			z++;
		}
		s++;
	}
	return (s);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		baselen;
	char	writex;

	baselen = ft_vl_base(base);
	if (baselen < 2)
		return ;
	if (nbr == -2147483648)
	{
		ft_putnbr_base(nbr / baselen, base);
		writex = base[-(nbr % baselen)];
		write(1, &writex, 1);
	}
	else if (nbr < 0)
	{
		write(1, "-", 1);
		nbr = -nbr;
		ft_putnbr_base(nbr, base);
	}
	else if (nbr >= baselen)
	{
		ft_putnbr_base((nbr / baselen), base);
		ft_putchar(base[nbr % baselen]);
	}
	else
		ft_putchar(base[nbr]);
}
