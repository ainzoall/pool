/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 18:25:16 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/20 18:26:03 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char				*stc;
	unsigned int		unb;

	unb = 0;
	stc = dest;
	while (*dest)
		dest++;
	if (*src == '\0')
		return (stc);
	while (unb < nb)
	{
		*dest = *src;
		dest++;
		src++;
		unb++;
	}
	*dest = '\0';
	return (stc);
}
