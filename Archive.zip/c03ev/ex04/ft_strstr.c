/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 13:03:06 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/22 18:28:02 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	if (to_find[0] == '\0')
		return (str);
	while (*str)
	{
		if (str[0] == to_find[0])
		{
			while (to_find[i] != '\0' && str[i] != '\0')
			{
				if (to_find[i] == str[i])
					j++;
				i++;
			}
			if (i == j && i != 1)
				return (str);
		}
		str++;
	}
	return (0);
}
