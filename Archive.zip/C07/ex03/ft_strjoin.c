/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: efelaous <efelaous@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/27 19:23:52 by efelaous          #+#    #+#             */
/*   Updated: 2023/07/31 22:24:47 by efelaous         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	size;

	size = 0;
	while (str[size] != '\0')
		size++;
	return (size);
}

int	ft_arrlen(char **strs, int ssize, char *str)
{
	int	i;
	int	j;
	int	size;

	i = 0;
	size = 0;
	while (i < ssize && strs[i] != 0)
	{
		j = 0;
		while (strs[i][j])
		{
			size++;
			j++;
		}
		i++;
	}
	return (size + (ft_strlen(str) * (ssize - 1)));
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*string;
	int		i;
	int		j;
	int		s;

	if (size == 0)
	{
		string = (char *) malloc(sizeof(char));
		string[0] = '\0';
		return (string);
	}
	string = malloc(sizeof(char) * ft_arrlen(strs, size, sep) + 1);
	i = -1;
	s = 0;
	while (++i < size && strs[i] != 0)
	{
		j = 0;
		while (strs[i][j])
			string[s++] = strs[i][j++];
		j = 0;
		while (sep[j] && i < size - 1)
			string[s++] = sep[j++];
	}
	string[s] = '\0';
	return (string);
}
